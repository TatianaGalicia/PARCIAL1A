﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PARCIAL1A.Models;

namespace PARCIAL1A.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AutorLibroController : ControllerBase
    {
        private readonly parcial1AContext _parcial1AContexto;
        public AutorLibroController(parcial1AContext parcial1AContexto)
        {
            _parcial1AContexto = parcial1AContexto;
        }
    }
}
